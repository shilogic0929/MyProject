<template>
<div>
  <h3>Welcome</h3>
</div>
</template>

<script>
export default {
  name: "Welcome.vue"
}
</script>

<style scoped>

</style>